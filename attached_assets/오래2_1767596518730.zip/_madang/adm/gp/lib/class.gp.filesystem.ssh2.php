<?php
/**
 * GPF SSH2 파일 시스템
 *
 * 이 파일은 워드프레스의 WP_Filesystem_SSH2 의 GPF 버전입니다.
 *
 * @package GPF 
 */

/**
 * GPF Filesystem Class for implementing SSH2.
 *
 * To use this class you must follow these steps for PHP 5.2.6+
 *
 * @contrib http://kevin.vanzonneveld.net/techblog/article/make_ssh_connections_with_php/ - Installation Notes
 *
 * Complie libssh2 (Note: Only 0.14 is officaly working with PHP 5.2.6+ right now, But many users have found the latest versions work)
 *
 * cd /usr/src
 * wget http://surfnet.dl.sourceforge.net/sourceforge/libssh2/libssh2-0.14.tar.gz
 * tar -zxvf libssh2-0.14.tar.gz
 * cd libssh2-0.14/
 * ./configure
 * make all install
 *
 * Note: Do not leave the directory yet!
 *
 * Enter: pecl install -f ssh2
 *
 * Copy the ssh.so file it creates to your PHP Module Directory.
 * Open up your PHP.INI file and look for where extensions are placed.
 * Add in your PHP.ini file: extension=ssh2.so
 *
 * Restart Apache!
 * Check phpinfo() streams to confirm that: ssh2.shell, ssh2.exec, ssh2.tunnel, ssh2.scp, ssh2.sftp  exist.
 *
 * Note: This utilises the PHP5+ function 'stream_get_contents'
 *
 * @package GPF
 * @uses GP_Filesystem_Base Extends class
 */
class GP_Filesystem_ssh2 extends GP_Filesystem_Base {

    var $link = false;
    var $sftp_link = false;
    var $keys = false;
    var $options = array();
    var $backurl;

    function __construct($opt = '') {
        global $backurl;

        $this->backurl = $backurl;
        $this->method = 'ssh2';

        //Check if possible to use ssh2 functions.
        if (!extension_loaded('ssh2')) {
            alert('SSH2 확장 모듈을 사용할 수 없습니다.', $backurl);
            return false;
        }
        if (!function_exists('stream_get_contents')) {
            alert('SSH2 확장 모듈을 사용 할 수 있지만, PHP5 함수인 stream_get_contents() 가 필요합니다.', $backurl);
            return false;
        }

        // Set defaults:
        if (empty($opt['port']))
            $this->options['port'] = 22;
        else
            $this->options['port'] = $opt['port'];

        if (empty($opt['hostname']))
            alert('호스트명을 입력하세요.', $backurl);
        else
            $this->options['hostname'] = $opt['hostname'];

        // Check if the options provided are OK.
        if (!empty($opt['public_key']) && !empty($opt['private_key'])) {
            $this->options['public_key'] = $opt['public_key'];
            $this->options['private_key'] = $opt['private_key'];

            $this->options['hostkey'] = array('hostkey' => 'ssh-rsa');

            $this->keys = true;
        } elseif (empty($opt['username'])) {
            alert('SSH2 사용자명을 입력하세요.', $backurl);
        }

        if (!empty($opt['username']))
            $this->options['username'] = $opt['username'];

        if (empty($opt['password'])) {
            if (!$this->keys) //password can be blank if we are using keys
                alert('SSH2 패스워드를 입력하세요', $backurl);
        } else {
            $this->options['password'] = $opt['password'];
        }
    }

    function connect() {
        if (!$this->keys) {
            $this->link = @ssh2_connect($this->options['hostname'], $this->options['port']);
        } else {
            $this->link = @ssh2_connect($this->options['hostname'], $this->options['port'], $this->options['hostkey']);
        }

        if (!$this->link) {
            alert('SSH2 서버 연결에 실패하였습니다.', $this->backurl);
            return false;
        }

        if (!$this->keys) {
            if (!@ssh2_auth_password($this->link, $this->options['username'], $this->options['password'])) {
                alert('SSH2 서버 로그인에 실패하였습니다. 사용자명과 패스워드를 확인하세요.', $this->backurl);
                return false;
            }
        } else {
            if (!@ssh2_auth_pubkey_file($this->link, $this->options['username'], $this->options['public_key'], $this->options['private_key'], $this->options['password'])) {
                alert('공개/비공개 키가 정확하지 않습니다.', $this->backurl);
                return false;
            }
        }

        $this->sftp_link = ssh2_sftp($this->link);

        return true;
    }

    function run_command($command, $returnbool = false) {

        if (!$this->link)
            return false;

        if (!($stream = ssh2_exec($this->link, $command))) {
            alert('명령을 수행할 수 없습니다 : ' . $command, $this->backurl);
        } else {
            stream_set_blocking($stream, true);
            stream_set_timeout($stream, FS_TIMEOUT);
            $data = stream_get_contents($stream);
            fclose($stream);

            if ($returnbool)
                return ( $data === false ) ? false : '' != trim($data);
            else
                return $data;
        }
        return false;
    }

    function get_contents($file, $type = '', $resumepos = 0) {
        $file = ltrim($file, '/');
        return file_get_contents('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function get_contents_array($file) {
        $file = ltrim($file, '/');
        return file('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function put_contents($file, $contents, $mode = false) {
        $file = ltrim($file, '/');
        $ret = file_put_contents('ssh2.sftp://' . $this->sftp_link . '/' . $file, $contents);

        $this->chmod($file, $mode);

        return false !== $ret;
    }

    function cwd() {
        $cwd = $this->run_command('pwd');
        if ($cwd)
            $cwd = trailingslashit($cwd);
        return $cwd;
    }

    function chdir($dir) {
        return $this->run_command('cd ' . $dir, true);
    }

    function chgrp($file, $group, $recursive = false) {
        if (!$this->exists($file))
            return false;
        if (!$recursive || !$this->is_dir($file))
            return $this->run_command(sprintf('chgrp %o %s', $mode, escapeshellarg($file)), true);
        return $this->run_command(sprintf('chgrp -R %o %s', $mode, escapeshellarg($file)), true);
    }

    function chmod($file, $mode = false, $recursive = false) {
        if (!$this->exists($file))
            return false;

        if (!$mode) {
            if ($this->is_file($file))
                $mode = FS_CHMOD_FILE;
            elseif ($this->is_dir($file))
                $mode = FS_CHMOD_DIR;
            else
                return false;
        }

        if (!$recursive || !$this->is_dir($file))
            return $this->run_command(sprintf('chmod %o %s', $mode, escapeshellarg($file)), true);
        return $this->run_command(sprintf('chmod -R %o %s', $mode, escapeshellarg($file)), true);
    }

    function chown($file, $owner, $recursive = false) {
        if (!$this->exists($file))
            return false;
        if (!$recursive || !$this->is_dir($file))
            return $this->run_command(sprintf('chown %o %s', $mode, escapeshellarg($file)), true);
        return $this->run_command(sprintf('chown -R %o %s', $mode, escapeshellarg($file)), true);
    }

    function owner($file) {
        $owneruid = @fileowner('ssh2.sftp://' . $this->sftp_link . '/' . ltrim($file, '/'));
        if (!$owneruid)
            return false;
        if (!function_exists('posix_getpwuid'))
            return $owneruid;
        $ownerarray = posix_getpwuid($owneruid);
        return $ownerarray['name'];
    }

    function getchmod($file) {
        return substr(decoct(@fileperms('ssh2.sftp://' . $this->sftp_link . '/' . ltrim($file, '/'))), 3);
    }

    function group($file) {
        $gid = @filegroup('ssh2.sftp://' . $this->sftp_link . '/' . ltrim($file, '/'));
        if (!$gid)
            return false;
        if (!function_exists('posix_getgrgid'))
            return $gid;
        $grouparray = posix_getgrgid($gid);
        return $grouparray['name'];
    }

    function copy($source, $destination, $overwrite = false, $mode = false) {
        if (!$overwrite && $this->exists($destination))
            return false;
        $content = $this->get_contents($source);
        if (false === $content)
            return false;
        return $this->put_contents($destination, $content, $mode);
    }

    function move($source, $destination, $overwrite = false) {
        return @ssh2_sftp_rename($this->link, $source, $destination);
    }

    function delete($file, $recursive = false, $type = false) {
        if ('f' == $type || $this->is_file($file))
            return ssh2_sftp_unlink($this->sftp_link, $file);
        if (!$recursive)
            return ssh2_sftp_rmdir($this->sftp_link, $file);
        $filelist = $this->dirlist($file);
        if (is_array($filelist)) {
            foreach ($filelist as $filename => $fileinfo) {
                $this->delete($file . '/' . $filename, $recursive, $fileinfo['type']);
            }
        }
        return ssh2_sftp_rmdir($this->sftp_link, $file);
    }

    function exists($file) {
        $file = ltrim($file, '/');
        return file_exists('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function is_file($file) {
        $file = ltrim($file, '/');
        return is_file('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function is_dir($path) {
        $path = ltrim($path, '/');
        return is_dir('ssh2.sftp://' . $this->sftp_link . '/' . $path);
    }

    function is_readable($file) {
        $file = ltrim($file, '/');
        return is_readable('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function is_writable($file) {
        $file = ltrim($file, '/');
        return is_writable('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function atime($file) {
        $file = ltrim($file, '/');
        return fileatime('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function mtime($file) {
        $file = ltrim($file, '/');
        return filemtime('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function size($file) {
        $file = ltrim($file, '/');
        return filesize('ssh2.sftp://' . $this->sftp_link . '/' . $file);
    }

    function touch($file, $time = 0, $atime = 0) {
        //Not implemented.
    }

    function mkdir($path, $chmod = false, $chown = false, $chgrp = false) {
        $path = untrailingslashit($path);
        if (empty($path))
            return false;

        if (!$chmod)
            $chmod = FS_CHMOD_DIR;
        if (!ssh2_sftp_mkdir($this->sftp_link, $path, $chmod, true))
            return false;
        if ($chown)
            $this->chown($path, $chown);
        if ($chgrp)
            $this->chgrp($path, $chgrp);
        return true;
    }

    function rmdir($path, $recursive = false) {
        return $this->delete($path, $recursive);
    }

    function dirlist($path, $include_hidden = true, $recursive = false) {
        if ($this->is_file($path)) {
            $limit_file = basename($path);
            $path = dirname($path);
        } else {
            $limit_file = false;
        }

        if (!$this->is_dir($path))
            return false;

        $ret = array();
        $dir = @dir('ssh2.sftp://' . $this->sftp_link . '/' . ltrim($path, '/'));

        if (!$dir)
            return false;

        while (false !== ($entry = $dir->read())) {
            $struc = array();
            $struc['name'] = $entry;

            if ('.' == $struc['name'] || '..' == $struc['name'])
                continue; //Do not care about these folders.

            if (!$include_hidden && '.' == $struc['name'][0])
                continue;

            if ($limit_file && $struc['name'] != $limit_file)
                continue;

            $struc['perms'] = $this->gethchmod($path . '/' . $entry);
            $struc['permsn'] = $this->getnumchmodfromh($struc['perms']);
            $struc['number'] = false;
            $struc['owner'] = $this->owner($path . '/' . $entry);
            $struc['group'] = $this->group($path . '/' . $entry);
            $struc['size'] = $this->size($path . '/' . $entry);
            $struc['lastmodunix'] = $this->mtime($path . '/' . $entry);
            $struc['lastmod'] = date('M j', $struc['lastmodunix']);
            $struc['time'] = date('h:i:s', $struc['lastmodunix']);
            $struc['type'] = $this->is_dir($path . '/' . $entry) ? 'd' : 'f';

            if ('d' == $struc['type']) {
                if ($recursive)
                    $struc['files'] = $this->dirlist($path . '/' . $struc['name'], $include_hidden, $recursive);
                else
                    $struc['files'] = array();
            }

            $ret[$struc['name']] = $struc;
        }
        $dir->close();
        unset($dir);
        return $ret;
    }

}
