<?php
/**
 *
 * GPF 코어 업그레이드 내역
 *
 * @package GPF
 * @author Chongmyung Park <byfun@byfun.com>
 * @copyright Chongmyung Park
 * @license GPLv2 License http://www.gnu.org/licenses/gpl-2.0.html
 * @link http://lovelyus.net
 * @since 2.0.0
 */
include_once '_common.php';
include_once GP_ADMIN_PATH . DS . 'head.php';
echo '<h1>업그레이드 내역</h1>';
if(GP_VERSION == '5.1.0') {
    echo '<div class="gpa_section">* [그누보드]/skin/member/.gp 와 [그누보드]/skin/search/.gp 는 더이상 사용되지 않습니다. 삭제해주세요.</div>';
}
echo '<pre>';
echo get_text(file_get_contents(GP_ADMIN_PATH . DS . 'history.txt'));
echo '</pre>';
include_once GP_ADMIN_PATH . DS . 'tail.php';

?>
