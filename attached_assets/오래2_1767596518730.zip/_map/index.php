<?php
define('_MAP_', true);
include_once('./_common.php');
include_once(G5_PATH.'/_head.php');
?>

<div id="sqCon">
<?php
if($map_id) {
// 수정, 삭제 링크
$update_href = $delete_href = '';
// 로그인중이고 자신의 글이라면 또는 관리자라면 패스워드를 묻지 않고 바로 수정, 삭제 가능
if (($member['mb_id']&&($member['mb_id']==$mapWrInfo['mb_id']))||$is_admin) {
    $update_href = G5_BBS_URL.'/write.php?w=u&amp;bo_table=map&amp;wr_id='.$map_id.'&amp;page='.$page;
    $delete_href = G5_BBS_URL.'/delete.php?bo_table=map&amp;wr_id='.$map_id.'&amp;page='.$page;
    if ($is_admin)
    {
//        set_session("ss_delete_token", $token = uniqid(time()));
		$token = get_session('ss_delete_token');
        $delete_href = G5_BBS_URL.'/delete.php?bo_table=map&amp;wr_id='.$map_id.'&amp;token='.$token.'&amp;page='.$page;
    }
}
	$commentNum = "";
	if($mapWrInfo['wr_comment']>0) $commentNum = "<span class='comment-num'>".$mapWrInfo['wr_comment']."</span>";
	$sVW = sql_fetch(" select vi_view from g5_visit where vi_ip = '{$_SERVER['REMOTE_ADDR']}' ");
	$con = explode("[Photo:",$mapWrInfo['wr_content']);
	$cnt = count($con);
	$wrContent = $con[0];
	for($i=1;$i<$cnt;$i++)
	{
		$con2 = explode("]",$con[$i]);
		$pId = $con2[0];
		$pCode = "[Photo:".$pId."]";
		$pInfo = sql_fetch(" select * from gpf_picasa where id = '{$pId}' ");
		$imgWidth = $pInfo['width'];
		if($sVW['vi_view']<$pInfo['width']) $imgWidth = "100%"; //$sVW['vi_view'];
		$dispN = " dispN";
//		if(G5_IS_MOBILE) $dispN = " dispN";
		$pHtml = "<div class='photoBox' id='BB".$pId."'>".PHP_EOL;
//		$pHtml .= "<img src='".$pInfo['imgurl']."' class='sect-photo' id='".$pId."'>".PHP_EOL;
		$pHtml .= "<img src='".$pInfo['imgurl']."' width='".$imgWidth."' class='lazyload' id='".$pId."'>".PHP_EOL;
		$pHtml .= "<div class='photoInfo'>";
		if($pInfo['summary'])
			$pHtml .= "<strong>".$pInfo['summary']."</strong><br />";
		if($pInfo['photo_date'])
			$pHtml .= "<i class='fa fa-camera'></i> ".$pInfo['photo_date']."<br />";
		if($pInfo['photo_content'])
			$pHtml .= $pInfo['photo_content'];
		$pHtml .= "</div>";
		$pHtml .= "<div class='mapBox".$dispN."' id='B".$pId."'>".PHP_EOL;
		$pHtml .= "<img src='http://maps.googleapis.com/maps/api/staticmap?";
		$pHtml .= "center=".getLat($pInfo['map_address']).",".getLng($pInfo['map_address']);
		$pHtml .= "&visible=".getLat($pInfo['map_address']).",".getLng($pInfo['map_address']);
		$pHtml .= "&markers=color:coral%7C".getLat($pInfo['map_address']).",".getLng($pInfo['map_address']);
		$pHtml .= "&size=280x200&zoom=15&sensor=false";
		$pHtml .= "' />";
		$pHtml .= "</div>".PHP_EOL;
		$pHtml .= "<button type='button' class='btn btn-default toggleMapBox' id='".$pId."'><i class='fa fa-map-marker'></i></button>";
		$pHtml .= "<button type='button' class='btn btn-default expandPhoto' rel='".$pInfo['width']."^".$pInfo['imgurl']."'><i class='fa fa-expand'></i></button>";
//		$pHtml .= "<div class='expandPhotoBox' id='exp".$pId."'></div>";
		$pHtml .= "</div>";
		$conPart = "[Photo:".$con[$i];
		$wrContent .= str_replace($pCode, $pHtml, $conPart);
	} 
	$rowDatetime10 = substr($mapWrInfo['wr_datetime'],0,10);
	if($rowDatetime10==G5_TIME_YMD)
		$rowDatetime = substr($mapWrInfo['wr_datetime'],11,8);
	else
		$rowDatetime = $rowDatetime10;
?>
	<div id="sqView">
		<div class="navBox">
			<a href="<?php echo G5_URL?>/_map/"><i class="fa fa-map-marker"></i> 증산순례지도</a>
		</div>
		<div id="subBtn">
			<button class="btn btn-default showSub" id="profile"><i class="fa fa-user"></i></button>
			<button class="btn btn-default showSub" id="comm"><i class="fa fa-comments"></i></button>
		</div>
		<div id="title">
			<h1 id="subject"><?php echo $mapWrInfo['wr_subject']?></h1>
			<span id="name"><?php echo $mapWrInfo['wr_name']?></span>
			<a class="btn btn-default btn-xs" href="javascript:;" onclick="window.open('<?php echo G5_BBS_URL?>/memo_form.php?me_recv_mb_id=<?php echo $mapWrInfo['mb_id']?>','name','resizable=no,width=550,height=500,status=no,scrollbars=yes,menubar=no');return false"><i class="fa fa-envelope-o"></i> 쪽지</a>
			<span id="cate"><?php echo $mapWrInfo['ca_name']?></span>
			<span id="dateTime"><?php echo $rowDatetime?></span>
			<span class="wrHit round5"><?php echo number_format($mapWrInfo['wr_hit'])?></span>
		</div>
		<div class='toolBox'>
		<?php if(!G5_IS_MOBILE&&($member['mb_id']==$mapWrInfo['mb_id']||$is_admin=='super')) { ?>
			<a class='btn btn-success' type='button' href='<?php echo $update_href?>'>수정</a>
			<a class='btn btn-danger' type='button' href='<?php echo $delete_href?>' onclick='del(this.href); return false;'>삭제</a>
		<?php } ?>
			<div class="padd10">
				<a type="button" class="btn btn-default scroll openCommentBox" href="#openCommentBox2" id="openCommentBox1" rel="map:<?php echo $map_id?>"><i class="fa fa-comment fa-2x"></i> <span class='commentNum' id='wrId<?php echo $map_id?>'><?php echo $commentNum?></span></a>
			</div>
		</div>
		<div id="sqContent">
		<?php echo $wrContent?>
		</div>
	<?php
	if($is_admin=='super') {
		if($mapWrInfo['wr_1']!='ok')
			echo '<div class="floL padd10"><button class="btn btn-primary" id="accessPhotos" rel="'.$map_id.':ok">사진등록 신청접수</button></div>';
		else
			echo '<div class="floL padd10"><button class="btn btn-warning" id="accessPhotos" rel="'.$map_id.':cancel">사진등록 신청접수 취소</button></div>';
	}
	?>
		<div class='toolBox'>
		<?php if(!G5_IS_MOBILE&&($member['mb_id']==$mapWrInfo['mb_id']||$is_admin=='super')) { ?>
			<a class='btn btn-success' type='button' href='<?php echo $update_href?>'>수정</a>
			<a class='btn btn-danger' type='button' href='<?php echo $delete_href?>' onclick='del(this.href); return false;'>삭제</a>
		<?php } ?>
			<div class="padd10">
				<button type="button" class="btn btn-default openCommentBox" id="openCommentBox2" rel="map:<?php echo $map_id?>"><i class="fa fa-comment fa-2x"></i> <span class='commentNum' id='wrId<?php echo $map_id?>'><?php echo $commentNum?></span></button>
			</div>
		</div>
		<div class="txtC padd10 cl-bo dispN" id="iconLoading"><img src="<?php echo G5_IMG_URL?>/ajaxLoader.gif" /></div>
		<div id="wrCommentsBox" class="cl-bo<?php if($mode=='openComment') { ?> open<?php } ?>">
			<?php if($mode=='openComment') include G5_PATH."/inc_commentList.php" ?>
		</div>
		<div id="subjCateListBoxWrap" class="round5">
<?php
		echo '<h2><i class="fa fa-map-marker"></i> '.$mapWrInfo['wr_name'].'님의 전체 지도정보</h2>';
?>
			<img src="<?php echo G5_IMG_URL?>/ajaxLoader.gif" id="subjCateListLoading" />
			<div id="subjCateListBox" class="innerPaging">
			<?php include G5_PATH."/inc_subjCateList.php";?>
			</div>
		</div>
		<div id="subjListBoxWrap">
			<h2><i class="fa fa-map-marker"></i> 증산순례지도 전체 지도정보</h2>
			<img src="<?php echo G5_IMG_URL?>/ajaxLoader.gif" id="subjListLoading" />
			<div id="subjListBox" class="innerPaging">
			<?php include G5_PATH."/inc_subjList.php";?>
			</div>
		</div>
	</div><!-- id="sqView"-->
<?php
//조회수 증가
$ss_name = 'ss_view_square_'.$map_id;
if (!get_session($ss_name))
{
	sql_query(" update {$map_table} set wr_hit = wr_hit + 1 where wr_id = '{$map_id}' ");
	// 자신의 글이면 통과
	if ($mapWrInfo['mb_id']&&$mapWrInfo['mb_id'] == $member['mb_id']) {
	;
	} else if ($is_guest&&$mapWrInfo['wr_ip']==$_SERVER['REMOTE_ADDR']) {
	// 비회원이면서 등록된 아이피가 같다면 자신의 글이므로 통과
	;
	}
	set_session($ss_name, TRUE);
}

} else { //$map_id가 없을 때

$uInfo = get_member($uId);
?>

		<div id="mainSect">
			<h2 id="sectTitle"><i class="fa fa-map-marker"></i> <?php if(!G5_IS_MOBILE||G5_IS_MOBILE&&!$uId) { ?>증산순례지도<?php } ?>
				<?php if($uId) echo "<i class='fa fa-angle-double-right'></i> ".$uInfo['mb_nick'] ?>
			</h2>
			<div id="subBtn">
			<?php if($uId) { ?>
				<button class="btn btn-default showSub" id="profile"><i class="fa fa-user"></i></button>
			<?php } ?>
				<button class="btn btn-default showSub" id="comm"><i class="fa fa-comments"></i></button>
			</div>
			<div id="mapSectBox" class="innerPaging">
				<?php include G5_PATH."/inc_mapSect.php";?>
			</div>
		</div>

<?php
} //$map_id가 없을 때
?>
</div><!-- id="sqCon"-->

<div id="sqSub" class="sqSubAbs">
	<button class="btn btn-default hideSub"><i class="fa fa-times"></i></button>
	<?php
		if($map_id||$uId) {
			if($map_id) {
				$uInfo = get_member($mapWrInfo['mb_id']);
//				$p_id = $map_id;
			}
			if($uId) {
				$uInfo = get_member($uId);
//				$p_id = $uId;
			}
	?>
	<div id="userBox">
		<!--i class="fa fa-user fa-3x round5" id="no-mb-icon3"></i-->
		<div id="writeName">
			<h2><?php echo $uInfo['mb_nick']?></h2>
			<a id="sendMemo" class="btn btn-default btn-xs" href="javascript:;" onclick="window.open('<?php echo G5_BBS_URL?>/memo_form.php?me_recv_mb_id=<?php echo $uInfo['mb_id']?>','name','resizable=no,width=550,height=500,status=no,scrollbars=yes,menubar=no');return false">쪽지보내기</a>
		</div>
		<img src="<?php echo G5_IMG_URL?>/ajaxLoader.gif" id="pfLoading" />
		<div id="pfBoxWrap"><?php include G5_PATH."/inc_profile.php"?></div>
	</div>
	<?php } ?>
	<div id="commentsBox">
		<h3 id="sub-title"><i class="fa fa-comments fa-2x"></i> 지도 전체 댓글</h3>
		<div id="commentsBoxWrap" class="commList">
			<?php include G5_PATH."/inc_commentBox.php";?>
		</div>
	</div>
</div><!-- id="sqSub"-->

<?php
include_once(G5_PATH.'/_tail.php');
?>