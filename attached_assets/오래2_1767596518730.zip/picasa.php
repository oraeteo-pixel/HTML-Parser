<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no"/>
<style type="text/css">
html { height : 100% }
body { height : 100%; margin: 0; padding: 0 }
#map_canvas { height : 100% }
</style>
<script type = "text/javascript" src = "http://maps.googleapis.com/maps/api/js?sensor=true"></script>
<script type = "text/javascript">

var map;
var infowindow;
var marker;

//infowindow 변수는 앞으로 띄울 정보창 오브젝트를 담는 변수입니다.
//초기화 함수뿐만 아니라, 다른 함수에서도 쓰일 것이기 때문에 변수를 initialize()밖 //에서 지정해줍니다.

/*****/
function initialize(){

var latlng = new google.maps.LatLng(35.7189000, 127.0280000);
var myOptions = {
zoom: 15,
center:latlng,
mapTypeId: google.maps.MapTypeId.ROADMAP
};
map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);


/*
var triangleCoords = [
new google.maps.LatLng(35.7189000, 127.0280000),
new google.maps.LatLng(35.7159000, 127.0250000),
new google.maps.LatLng(35.7159000, 127.0310000)
];

        GsTriangle = new google.maps.Polygon({
                                paths: triangleCoords,
                                strokeColor: "#FF0000",
                                strokeOpacity: 0.8,
                                strokeWeight: 1,
                                fillColor: "#FF0000",
                                fillOpacity: 0.35
                              });
*/
							  
//google.maps.event.addListener(GsTriangle, 'click', showInfowindow);
google.maps.event.addListener(map, 'click', Setmarker);

/* 이 부분이 'YeouidoTriangle이라는 polygon object를 클릭할 경우 
showInfowindow라는 함수를 실행한다'라는 부분입니다.
      google maps API의 event class를 사용, 이런 명령을 실행할 수 있습니다.
      다음 글에서 event에 대해서 조금 더 자세히 설명하겠습니다.*/

        infowindow = new google.maps.InfoWindow();
        //infowindow 변수를 InfoWindow class 형식으로 할당합니다.

//        GsTriangle.setMap(map);

    };
	
	
 function Setmarker(event) {
         marker = new google.maps.Marker({
    position: event.latLng,
    map: map
   } );
	
   infowindow.setContent("This is marked now.");
   infowindow.open(map,marker);
	
	};
/*
    function showInfowindow(event) {
            
            
        infowindow.setContent ("GeumSanMyeon");
        infowindow.setPosition (event.latLng);

        infowindow.open (map);
} */
/* infowindow를 띄우는 함수입니다. 위의 event 부분 때문에 polygon을 클릭할 때 실행되게 됩니다. 
      첫번째 줄의 setContent 함수는 infowindow 내부의 내용을 설정하는 함수이고, 
      두번째 줄의 setPosition 함수는 infowindow가 표시되는 좌표를 설정하는 함수입니다      .*/

</script>
</head>
<body onload="initialize()">
    <div id="map_canvas"></div>
</body>
</html>
