<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 하단 파일 경로 지정 : 이 코드는 가능한 삭제하지 마십시오.
if ($config['cf_include_tail']) {
    if (!@include_once($config['cf_include_tail'])) {
        die('기본환경 설정에서 하단 파일 경로가 잘못 설정되어 있습니다.');
    }
    return; // 이 코드의 아래는 실행을 하지 않습니다.
}
/*
if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/tail.php');
    return;
}
*/
?>
</div><!--- id="con-wrap"--->

<div id="bottom-box" class="body-wrap">
	<div id="visitBox"><?php echo visit('ort')?></div>
	<div id="copyRight">
		copyright&copy;오리알터닷컴 since 2014.05.17
	</div>
</div>

<?php
include_once(G5_PATH."/tail.sub.php");
?>