<?php
include_once('./_common.php');


if($act=='do') {

$do = sql_query(" select * from g5_write_calendar where wr_is_comment = 0 order by wr_id ");
echo "WHY?";
for($l=0;$row=sql_fetch_array($do);$l++) {
sql_query("
	update g5_write_calendar set
		wr_1 = '{$row['wr_id']}'
		where wr_id = '{$row['wr_id']}'
");
echo '<li>'.$row['wr_id'].' / '.$row['wr_1'].'</li>';
}

}

?>
